/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
int main()
{
    int prno,i,n,flag;
	printf(" Input a number: ");
	scanf("%d",&prno);
    for(i=1;i<=prno;i++)
        {
            if(i*(i+1)==prno) 
            {
            flag=1;
            break;
            }
        }
  
            if(flag==1)
            {
			printf(" The given number is a Pronic Number.\n");
            }
            else
            {
			printf(" The given number is not a Pronic Number.\n");
            }
}
